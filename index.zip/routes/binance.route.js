const express = require("express");
const router = express.Router();
const {createO,callback,checkPaymentStatus} = require("../controllers/binance.controller");

router.post("/create", createO);
router.post("/callback", callback);
router.post("/check", checkPaymentStatus);


module.exports = router; 
