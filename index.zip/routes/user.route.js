const express = require("express");
const router = express.Router();
const {
  editProfile,
  getUser,
  users,
  deleteUser,
  admins,
  blockUser,
  deleteSelectedUsers,
  twoFA,
  webNotification,
  emailToggle,
  emailNotification,
  initiateChangePassword,
  verifyChangePasswordOTP
} = require("../controllers/user.controller");
const { verifyToken } = require("../middleware/verify");

router.get("/profile", verifyToken, getUser);
router.post("/settings/personal", verifyToken, editProfile);
router.get("/", verifyToken, users);
router.get("/two-fa", verifyToken, twoFA);
router.get("/email-toggle", verifyToken, emailToggle);
router.post("/email-notification", verifyToken, emailNotification);
router.post("/web-notification", verifyToken, webNotification);
router.post("/change-password/initiate", verifyToken, initiateChangePassword);
router.post("/change-password/verify", verifyToken, verifyChangePasswordOTP);
router.delete("/delete-user/:id", verifyToken, deleteUser);
router.delete("/delete/selected", verifyToken, deleteSelectedUsers);
router.get("/all/admins/", verifyToken, admins);
router.patch("/block-user/:id", verifyToken, blockUser);

module.exports = router;