const express = require("express");
const router = express.Router();
const { find,fetchRoomRates,recheck,book} = require("../controllers/hotels.controller");

// router.post("/findhotels", findHotels);
router.post("/find", find);
router.post("/rooms", fetchRoomRates);
router.post("/recheck", recheck);
router.post("/book", book);




module.exports = router;
