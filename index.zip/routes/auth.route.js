const express = require("express");
const router = express.Router();
const { signup, signin, google, activate, resendOTP, requestPasswordReset, verifyOTP, resetPassword } = require("../controllers/auth.controller");

router.post("/signup", signup);
router.post("/activate", activate);
router.post("/resend-otp", resendOTP);
router.post("/signin", signin);
router.post('/password-reset/request', requestPasswordReset);
router.post('/password-reset/verify-otp', verifyOTP);
router.post('/password-reset/reset', resetPassword);

 

module.exports = router;
