const express = require("express");
const { tapToIncreaseCoins,getCoinsBalance,items,statistics } = require("../controllers/profile.controller"); 
const {verifyToken} = require("../middleware/verify")

const router = express.Router();

router.post("/:id/tap",verifyToken, tapToIncreaseCoins);
router.get("/:id/coins/balance",verifyToken, getCoinsBalance);
router.get("/:id/items",verifyToken, items);
router.get("/:id/statistics",verifyToken, statistics);


module.exports = router;