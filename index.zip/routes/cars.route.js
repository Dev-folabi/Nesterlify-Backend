const express = require("express");
const router = express.Router();
const { findcar ,bookTransfer} = require("../controllers/cars.controller");

router.post("/findcar", findcar);
router.post("/book", bookTransfer);



 

module.exports = router;
