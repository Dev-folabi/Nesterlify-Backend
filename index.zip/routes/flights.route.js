const express = require("express");
const router = express.Router();
const {roundtrip,oneway,recheck} = require("../controllers/flights.controller");

router.post("/round-trip", roundtrip);
router.post("/one-way", oneway);
router.post("/recheck", recheck);
router.post("/book", recheck);





module.exports = router;
