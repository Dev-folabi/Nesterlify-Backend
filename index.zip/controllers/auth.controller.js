const User = require("../models/user.model");
const bcryptjs = require("bcryptjs");
const { errorHandler } = require("../middleware/errorHandler");
const jwt = require("jsonwebtoken");
const sendMail = require("../middleware/sendMail");


const usersPendingActivation = {};

const passwordRegex = /^(?=.*[a-z].*[a-z])(?=.*[A-Z].*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{6,}$/;


exports.signup = async (req, res, next) => {
  const { username, fullName, email, password, confirmPassword } = req.body; 

 
    if (password !== confirmPassword) {
      return next(errorHandler(400, "Password and confirm password do not match."));
    }

  if (!passwordRegex.test(password)) {
    return next(errorHandler(400, "Password does not meet the required complexity. It must be at least 6 characters long, contain at least 2 lowercase letters, 2 uppercase letters, 1 number, and 1 special character."));
  }

  const hashedPassword = bcryptjs.hashSync(password, 10);

  const activationCode = Math.floor(100000 + Math.random() * 900000);

  const expirationTime = Date.now() + 5 * 60 * 1000;
  const userEmail = await User.findOne({ email });
  if (userEmail) {
    return next(errorHandler(401, "User with this email already exists")); 
  }

  const userUsername = await User.findOne({ username });
  if (userUsername) {
    return next(errorHandler(401, "Username is already taken"));
  }

  console.log(activationCode);

  await sendMail({
    email: email,
    subject: `Your Activation Code for Nesterlify`,
    message: `
      Thank you for signing up for Nesterlify! To complete your registration, please use the following activation code:

      ${activationCode}

      Please enter this code on the activation page within 5 minutes to verify your email address and activate your account.

      If you did not sign up for an account, please disregard this email.

      Thank you,
      The Nesterlify Team
    `,
  });


  usersPendingActivation[email] = {
    fullName,
    email,
    username,
    password: hashedPassword,
    activationCode,
    expirationTime,
  };


  res.status(200).json({
    message:
      "User registered. Please check your email for the activation code.",
  });
};

exports.activate = async (req, res, next) => {
  const { email, activationCode } = req.body;

  const userEmail = await User.findOne({ email });
  if (userEmail) {
    return next(
      errorHandler(401, "Account activated already! proceed to login")
    );
  }

  if (!usersPendingActivation[email]) {
    return next(errorHandler(401, "Invalid or expired activation code"));
  }

  const userData = usersPendingActivation[email];

  if (Date.now() > userData.expirationTime) {
    return next(errorHandler(401, "Activation code has expired"));
  }

  if (userData.activationCode === parseInt(activationCode)) {
    const newUser = new User({
      fullName: userData.fullName,
      email: userData.email,
      password: userData.password,
      username: userData.username
    });



    try {
      await newUser.save();

      const token = jwt.sign({ id: newUser._id }, process.env.JWT_SECRET, {
        expiresIn: "1h",
      });

      const { password: hashedPasswordOmitted, ...user } = newUser._doc;

      res.status(200).json({
        user,
        token,
      });
      delete usersPendingActivation[email];
    } catch (error) {
      next(errorHandler(401, "Unable to activate the account"));
    }
  } else {
    next(errorHandler(401, "Invalid activation code"));
  }
};

exports.resendOTP = async (req, res, next) => {
  const { email } = req.body;

  const userEmail = await User.findOne({ email });
  if (userEmail) {
    return next(
      errorHandler(401, "Account activated already! proceed to login")
    );
  }

  if (!usersPendingActivation[email]) {
    return next(errorHandler(401, "Something went wrong, please try again!"));
  }

  const userData = usersPendingActivation[email];
  const activationCode = Math.floor(100000 + Math.random() * 900000);
  const expirationTime = Date.now() + 5 * 60 * 1000;

  userData.activationCode = activationCode;
  userData.expirationTime = expirationTime;

  console.log(activationCode);
  try {
    await sendMail({
      email: email,
      subject: `Your New Activation Code for Nesterlify`, 
      message: `
Your new activation code is:

${activationCode}

Please enter this code on the activation page within 5 minutes to verify your email address and activate your account.

If you did not sign up for an account, please disregard this email.

Thank you,
The Nesterlify Team
            `,
    });

    res
      .status(200)
      .json({ message: "A new activation code has been sent to your email." });
  } catch (error) {
    next(errorHandler(500, "Unable to send the activation code"));
  } 
};

exports.signin = async (req, res, next) => {
  const { email, password } = req.body;
  try {
    const validUser = await User.findOne({ email })
    if (!validUser) {
      return next(errorHandler(404, "User not found"));
    }
    const validPassword = bcryptjs.compareSync(password, validUser.password);
    if (!validPassword) {
      return next(errorHandler(401, "Wrong Signin Credential"));
    }
    const token = jwt.sign({ id: validUser._id }, process.env.JWT_SECRET, {
      expiresIn: "1h",
    });
    return res.status(200).json({ status:200, validUser, token });
  } catch (error) {
    next(error);
  }
};


// PASSWORD RESET

const usersPendingPasswordReset = {};

exports.requestPasswordReset = async (req, res, next) => {
  const { email } = req.body;

  const user = await User.findOne({ email });
  if (!user) {
    return next(errorHandler(404, "User with this email not found"));
  }

  const otpCode = Math.floor(100000 + Math.random() * 900000);
  const expirationTime = Date.now() + 5 * 60 * 1000;

  usersPendingPasswordReset[email] = {
    otpCode,
    expirationTime,
  };

  console.log(otpCode);
  try {
    await sendMail({
      email,
      subject: "Password Reset OTP Code",
      message: `
        You requested a password reset for your account. Use the OTP code below to proceed:

        ${otpCode}

        This OTP is valid for 5 minutes.

        If you did not request a password reset, please ignore this email.
      `,
    });

    res.status(200).json({ message: "OTP sent to your email." });
  } catch (error) {
    next(errorHandler(500, "Failed to send OTP"));
  }
};

exports.verifyOTP = async (req, res, next) => {
  const { email, otpCode } = req.body;

  const resetRequest = usersPendingPasswordReset[email];
  if (!resetRequest) {
    return next(errorHandler(400, "Invalid or expired OTP"));
  }

  if (Date.now() > resetRequest.expirationTime) {
    return next(errorHandler(400, "OTP has expired"));
  }

  if (resetRequest.otpCode !== parseInt(otpCode)) {
    return next(errorHandler(400, "Invalid OTP code"));
  }

  res
    .status(200)
    .json({
      message: "OTP verified successfully. You can now reset your password.",
    });
};

exports.resetPassword = async (req, res, next) => {
  const { email, newPassword, confirmNewPassword } = req.body;

  if (!passwordRegex.test(newPassword)) {
    return next(errorHandler(400, "Password does not meet the required complexity. It must be at least 6 characters long, contain at least 2 lowercase letters, 2 uppercase letters, 1 number, and 1 special character."));
  }

  if (newPassword !== confirmNewPassword) {
    return next(errorHandler(400, "Passwords do not match"));
  }

  const user = await User.findOne({ email });
  if (!user) {
    return next(errorHandler(404, "User not found"));
  }

  const hashedPassword = bcryptjs.hashSync(newPassword, 10);

  try {
    user.password = hashedPassword;
    await user.save();

    delete usersPendingPasswordReset[email];

    res.status(200).json({ message: "Password reset successfully." });
  } catch (error) {
    next(errorHandler(500, "Failed to reset password"));
  }
};