const axios = require('axios');



exports.findcar = async (req, res) => {
    const { startLocationCode, endAddressLine, endCityName, startDateTime } = req.body;

    if (!startLocationCode || !endAddressLine || !endCityName || !startDateTime) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    try {
        const tokenResponse = await axios.post(
            'https://test.api.amadeus.com/v1/security/oauth2/token',
            new URLSearchParams({
                'grant_type': 'client_credentials',
                'client_id': '5uxkVG4co4YSRMzzudTCNwroKBNsmuxy',
                'client_secret': 'wn1qSOg2MAZCFEQu'
            }).toString(),
            {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
            }
        );

        const bearerToken = tokenResponse.data.access_token;

        const transferResponse = await axios.post(
            'https://test.api.amadeus.com/v1/shopping/transfer-offers',
            {
                startLocationCode,
                endAddressLine,
                endCityName,
                startDateTime
            },
            {
                headers: {
                    Authorization: `Bearer ${bearerToken}`,
                },
            }
        );


        return res.status(200).json(transferResponse.data);

    } catch (error) {

        console.error(error);
        return res.status(500).json({
            error: error.response ? error.response.data : error.message,
        });
    }
};


exports.bookTransfer = async (req, res) => {
    const { transferOfferId, passengers, agency, payment } = req.body;

    if (!transferOfferId || !passengers || !agency || !payment) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    try {

        const tokenResponse = await axios.post(
            'https://test.api.amadeus.com/v1/security/oauth2/token',
            new URLSearchParams({
                'grant_type': 'client_credentials',
                'client_id': '5uxkVG4co4YSRMzzudTCNwroKBNsmuxy', 
                'client_secret': 'wn1qSOg2MAZCFEQu'
            }).toString(),
            {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
            }
        );

        const bearerToken = tokenResponse.data.access_token;

        const bookingResponse = await axios.post(
            `https://test.api.amadeus.com/v1/ordering/transfer-orders?offerId=${transferOfferId}`,
            {
                data: {
                    note: "Note to driver",
                    passengers: passengers,
                    agency: agency,
                    payment: payment,
                },
            },
            {
                headers: {
                    Authorization: `Bearer ${bearerToken}`,
                    'Content-Type': 'application/json',
                },
            }
        );


        return res.status(200).json(bookingResponse.data);
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            error: error.response ? error.response.data : error.message,
        });
    }
};
