const axios  = require('axios'); 
const crypto = require('crypto');




exports.callback = async(req, res) => {
    const payload = req.body;
    console.log('Payment Notification:', payload);
    res.status(200).send('OK');
}

exports.createO = async (req, res) => {
    const { amount, currency, orderId } = req.body;
    const BASE_URL = 'https://bpay.binanceapi.com';
    

    const BINANCE_API_KEY = process.env.BINANCE_API_KEY || '1axaoo09q4fxttj2h6mj9of23x9ltsuj8jpwceks4l2q4mj9dlrl3jk4aa1ipsso';
    const BINANCE_SECRET_KEY = process.env.BINANCE_SECRET_KEY || '0vcf5wqkpk06utm7wxkl5xiulhiywcuky8j4kizrw7d9yq41fqfu5hhgqlhvp6d3';


    const payload = {
        env: {
            terminalType: 'WEB'
        },
        merchantTradeNo: orderId,
        orderAmount: parseFloat(amount).toFixed(2), 
        currency: currency.toUpperCase(),
        goods: {
            goodsType: "01",
            goodsCategory: "0000",
            referenceGoodsId: orderId,
            goodsName: "Digital Service Payment",
            goodsDetail: "Payment for digital services"
        },
        tradeType: 'WEB',
        timeout: 1800,
        returnUrl: process.env.RETURN_URL || 'https://your-domain.com/return',
        cancelUrl: process.env.CANCEL_URL || 'https://your-domain.com/cancel',
        webhookUrl: process.env.WEBHOOK_URL || 'https://your-domain.com/webhook'
    };

    const timestamp = Date.now().toString();
    const nonce = crypto.randomBytes(16).toString('hex');
    const payloadString = JSON.stringify(payload, null, 0);
    const signatureString = `${timestamp}\n${nonce}\n${payloadString}\n`;
    
    const signature = crypto
        .createHmac('sha512', BINANCE_SECRET_KEY)
        .update(signatureString)
        .digest('hex')
        .toUpperCase();


    try {
       
        console.log('Request Details:', {
            url: `${BASE_URL}/binancepay/openapi/v2/order`,
            payload: payload,
            headers: {
                timestamp,
                nonce,
                signature: signature.substring(0, 10) + '...' 
            }
        });

        const response = await axios.post(
            `${BASE_URL}/binancepay/openapi/v2/order`,
            payload,
            {
                headers: {
                    'Content-Type': 'application/json',
                    'BinancePay-Timestamp': timestamp,
                    'BinancePay-Nonce': nonce,
                    'BinancePay-Certificate-SN': BINANCE_API_KEY,
                    'BinancePay-Signature': signature
                },
                timeout: 10000
            }
        );

        if (response.data.status === 'SUCCESS') {
            res.json(response.data);
        } else {
            throw new Error(response.data.errorMessage || 'Binance Pay request failed');
        }

    } catch (error) {
        console.error('Binance Pay Error:', {
            message: error.message,
            response: error.response?.data,
            timestamp,
            nonce,
            signatureString,
            signature
        });
        
        res.status(error.response?.status || 500).json({
            status: 'ERROR',
            error: error.response?.data || error.message,
            details: 'Check server logs for debugging information'
        });
    }
};




exports.checkPaymentStatus = async (req, res) => {
    const { orderId } = req.body; // Your unique order ID
    const BASE_URL = 'https://bpay.binanceapi.com';
    
    const BINANCE_API_KEY = process.env.BINANCE_API_KEY || '1axaoo09q4fxttj2h6mj9of23x9ltsuj8jpwceks4l2q4mj9dlrl3jk4aa1ipsso';
    const BINANCE_SECRET_KEY = process.env.BINANCE_SECRET_KEY || '0vcf5wqkpk06utm7wxkl5xiulhiywcuky8j4kizrw7d9yq41fqfu5hhgqlhvp6d3';



    const payload = {
        merchantTradeNo: orderId
    };

    const timestamp = Date.now().toString();
    const nonce = crypto.randomBytes(16).toString('hex');
    const payloadString = JSON.stringify(payload, null, 0);
    const signatureString = `${timestamp}\n${nonce}\n${payloadString}\n`;

    const signature = crypto
        .createHmac('sha512', BINANCE_SECRET_KEY)
        .update(signatureString)
        .digest('hex')
        .toUpperCase();

    try {
        const response = await axios.post(
            `${BASE_URL}/binancepay/openapi/v2/order/query`,
            payload,
            {
                headers: {
                    'Content-Type': 'application/json',
                    'BinancePay-Timestamp': timestamp,
                    'BinancePay-Nonce': nonce,
                    'BinancePay-Certificate-SN': BINANCE_API_KEY,
                    'BinancePay-Signature': signature
                },
                timeout: 10000
            }
        );

        if (response.data.status === 'SUCCESS') {
            res.json({
                status: 'SUCCESS',
                paymentStatus: response.data.data.status,
                details: response.data.data
            });
        } else {
            throw new Error(response.data.errorMessage || 'Failed to query payment status');
        }
    } catch (error) {
        console.error('Payment Status Check Error:', {
            message: error.message,
            response: error.response?.data,
            timestamp,
            nonce,
            signatureString,
            signature
        });

        res.status(error.response?.status || 500).json({
            status: 'ERROR',
            error: error.response?.data || error.message,
            details: 'Check server logs for debugging information'
        });
    }
};
