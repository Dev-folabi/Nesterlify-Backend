const User = require('../models/user.model');
const { errorHandler } = require('../middleware/errorHandler');
const bcryptjs = require("bcryptjs");
const jwt = require("jsonwebtoken");
const sendMail = require("../middleware/sendMail");



exports.getUser = async (req, res, next) => {
    try {
        const user = await User.findById(req.user.id).select('-password');
        if (!user) {
            return next(errorHandler(404, 'User not found'));
        }
        res.status(200).json(user);
    } catch (error) {
        next(error);
    }
};

exports.editProfile = async (req, res, next) => {
    const {
        profilePicture,
        title,
        gender,
        firstName,
        lastName,
        middleName,
        phoneNumber,
        nationality,
        state,
        city,
        zipcode,
        houseNo,
        houseAddress,
        documenttype,
        issuedby,
        passportNo,
        passportExpiryDate,
        dirthOfBirth

    } = req.body;

    try {
        const editedProfile = await User.findOneAndUpdate(
            { _id: req.user.id },
            {
                $set: {
                    profilePicture,
                    title,
                    gender,
                    firstName,
                    lastName,
                    middleName,
                    phoneNumber,
                    nationality,
                    state,
                    city,
                    zipcode,
                    houseNo,
                    houseAddress,
                    documenttype,
                    issuedby,
                    passportNo,
                    passportExpiryDate,
                    dirthOfBirth
                }
            },
            { new: true }
        );

        if (!editedProfile) {
            return next(errorHandler(404, 'User not found'));
        }

        const { password, ...rest } = editedProfile._doc;
        res.status(200).json(rest);
    } catch (error) {
        next(error);
    }
};


exports.twoFA = async (req, res, next) => {
    try {
        const user = await User.findById(req.user.id);

        if (!user) {
            return next(errorHandler(404, "User not found"));
        }
        user.twoFa = !user.twoFa;

        await user.save();
        res.status(200).json({ message: "2-Factor authentication has been toggled", user });
    } catch (error) {
        next(error);
    }
};

exports.emailToggle = async (req, res, next) => {
    try {
        const user = await User.findById(req.user.id);

        if (!user) {
            return next(errorHandler(404, "User not found"));
        }
        user.emailNotification = !user.emailNotification;

        await user.save();
        res.status(200).json({ message: "Email notification has been toggled", user });
    } catch (error) {
        next(error);
    }
};

exports.webNotification = async (req, res, next) => {
    try {

        const user = await User.findById(req.user.id);
        if (!user) {
            return next(errorHandler(404, "User not found"));
        }

        const { bookings, cheapflight, transaction } = req.body;

        if (typeof bookings === 'boolean') {
            user.notificationSettings.website.bookings = bookings;
        }
        if (typeof cheapflight === 'boolean') {
            user.notificationSettings.website.cheapflight = cheapflight;
        }
        if (typeof transaction === 'boolean') {
            user.notificationSettings.website.transaction = transaction;
        }

        await user.save();
        res.status(200).json({
            message: "Website notification settings updated successfully",
            notificationSettings: user.notificationSettings,
        });
    } catch (error) {
        next(error);
    }
};


exports.emailNotification = async (req, res, next) => {
    try {

        const user = await User.findById(req.user.id);
        if (!user) {
            return next(errorHandler(404, "User not found"));
        }

        const { bookings, cheapflight, transaction } = req.body;

        if (typeof bookings === 'boolean') {
            user.notificationSettings.email.bookings = bookings;
        }
        if (typeof cheapflight === 'boolean') {
            user.notificationSettings.email.cheapflight = cheapflight;
        }
        if (typeof transaction === 'boolean') {
            user.notificationSettings.email.transaction = transaction;
        }

        await user.save();
        res.status(200).json({
            message: "Email notification settings updated successfully",
            notificationSettings: user.notificationSettings,
        });
    } catch (error) {
        next(error);
    }
};



//Change password 

const passwordRegex = /^(?=.*[a-z].*[a-z])(?=.*[A-Z].*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{6,}$/;

const usersPendingPasswordChange = {};


exports.initiateChangePassword = async (req, res, next) => {
    const { email, oldPassword, newPassword, confirmNewPassword } = req.body;
    if (!passwordRegex.test(newPassword)) {
        return next(errorHandler(400, "Password does not meet the required complexity."));
    }

    if (newPassword !== confirmNewPassword) {
        return next(errorHandler(400, "New passwords do not match."));
    }

    try {
        const user = await User.findOne({ email });
        if (!user) {
            return next(errorHandler(404, "User not found."));
        }

        const validPassword = bcryptjs.compareSync(oldPassword, user.password);
        if (!validPassword) {
            return next(errorHandler(401, "Old password is incorrect."));
        }

        const otpCode = Math.floor(100000 + Math.random() * 900000);
        const expirationTime = Date.now() + 5 * 60 * 1000;

        usersPendingPasswordChange[email] = {
            otpCode,
            expirationTime,
            newPassword,
        };

        console.log(otpCode);

        await sendMail({
            email,
            subject: "Change Password OTP Code",
            message: `
        You requested to change your password. Use the OTP code below to proceed:

        ${otpCode}

        This OTP is valid for 5 minutes.

        If you did not request this, please ignore this email.
      `,
        });

        res.status(200).json({ message: "OTP sent to your email." });
    } catch (error) {
        next(errorHandler(500, "Failed to initiate password change."));
    }
};

// Verify OTP and change password
exports.verifyChangePasswordOTP = async (req, res, next) => {
    const { email, otpCode } = req.body;

    const changeRequest = usersPendingPasswordChange[email];
    if (!changeRequest) {
        return next(errorHandler(400, "Invalid or expired OTP."));
    }

    if (Date.now() > changeRequest.expirationTime) {
        return next(errorHandler(400, "OTP has expired."));
    }

    if (changeRequest.otpCode !== parseInt(otpCode)) {
        return next(errorHandler(400, "Invalid OTP code."));
    }

    try {

        const hashedPassword = bcryptjs.hashSync(changeRequest.newPassword, 10);
        const user = await User.findOne({ email });
        if (!user) {
            return next(errorHandler(404, "User not found."));
        }

        user.password = hashedPassword;
        await user.save();

        delete usersPendingPasswordChange[email];

        res.status(200).json({ message: "Password changed successfully." });
    } catch (error) {
        next(errorHandler(500, "Failed to change password."));
    }
};



exports.users = async (req, res, next) => {
    try {
        const users = await User.find({});
        res.status(200).json({
            success: true,
            UsersFound: users.length,
            users,
        });
    } catch (error) {
        console.log(error);
        return next(errorHandler(500, error.message));
    }
};

exports.deleteUser = async (req, res, next) => {
    try {
        const user = await User.findById(req.params.id);

        if (!user) {
            return next(errorHandler(404, 'User is not available with this id'));
        }


        await User.findByIdAndDelete(req.params.id);

        res.status(201).json({
            success: true,
            message: "User deleted successfully!",
        });
    } catch (error) {
        next(error);
    }


}

exports.admins = async (req, res, next) => {
    try {
        const allAdmin = await User.find({ role: 'admin' })
            .select('-password')
            .sort({ createdAt: -1 });

        res.status(200).json({
            success: true,
            AdminsFound: allAdmin.length,
            allAdmin,
        });
    } catch (error) {
        return next(errorHandler(500, error.message));
    }
};

exports.blockUser = async (req, res, next) => {
    try {
        const user = await User.findByIdAndUpdate(req.params.id, { isBlocked: true }, { new: true });
        if (!user) {
            return next(errorHandler(404, "User not found"));
        }
        res.status(200).json({ message: "User blocked successfully", user });
    } catch (error) {
        next(error);
    }
};

exports.deleteSelectedUsers = async (req, res, next) => {
    try {
        const { ids } = req.body;
        await User.deleteMany({ _id: { $in: ids } });
        return res.status(200).json({ msg: "Selected users have been deleted" });
    } catch (error) {
        next(error);
    }
};
