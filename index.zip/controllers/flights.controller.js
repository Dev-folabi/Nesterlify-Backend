const { Duffel } = require('@duffel/api');
const axios = require('axios');



const duffel = new Duffel({
  token: 'duffel_test_rvtiZjvWiLHbp7svOmWW9nEeef7aQQN5t_piCBLiJ2a',
});

exports.oneway = async (req, res) => {
  const {
    slices,
    passengers,
    cabin_class
  } = req.body;

  if (!slices || !passengers || !cabin_class) {
    return res.status(400).json({ error: 'Missing required fields: slices, passengers, or cabin_class' });
  }

  try {

    const offerRequest = await duffel.offerRequests.create({
      slices: slices,
      passengers: passengers,
      cabin_class: cabin_class,
    });


    res.json(offerRequest);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error });
  }
};


exports.roundtrip = async (req, res) => {
  const {
    slices,
    passengers,
    cabin_class
  } = req.body;

  if (!slices || !passengers || !cabin_class) {
    return res.status(400).json({ error: 'Missing required fields: slices, passengers, or cabin_class' });
  }

  try {

    const offerRequest = await duffel.offerRequests.create({
      slices: slices,
      passengers: passengers,
      cabin_class: cabin_class,
    });


    res.json(offerRequest);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error });
  }
};

 
exports.recheck = async (req, res) => {
  const { offer_id } = req.body;


  if (!offer_id) {
    return res.status(400).json({ error: 'Missing offer_id' });
  }

  try {
    const offer = await duffel.offers.get(offer_id);
    res.json(offer);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error });
  }
};


// exports.book = async (req, res) => {
//   const {
//     offer_id,
//     passengers,
//     payment_method,
//     total_amount,
//     total_currency,
//   } = req.body;


//   if (!offer_id || !passengers || !payment_method || !total_amount || !total_currency) {
//     return res.status(400).json({ error: 'Missing required fields' });
//   }

//   try {
//     const order = await duffel.orders.create({
//       selected_offers: [offer_id],
//       payments: [
//         {
//           type: payment_method.type, 
//           currency: total_currency,
//           amount: total_amount,
//         },
//       ],
//       passengers: passengers,
//     });

//     res.json(order);
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ error });
//   }
// };


exports.book = async (req, res) => {
  const {
    offer_id,
    total_amount,
    total_currency,
    passengers,
  } = req.body;


  if (!offer_id || !total_amount || !total_currency || !passengers || passengers.length === 0) {
    return res.status(400).json({ error: 'Missing required fields: offer_id, total_amount, total_currency, or passengers' });
  }

  try {

    const orderRequest = {
      data: {
        selected_offers: [offer_id],
        payments: [
          {
            type: "balance",
            currency: total_currency,
            amount: total_amount,
          }
        ],
        passengers: passengers,
      }
    };


    const order = await duffel.orders.create(orderRequest);

    res.json(order);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error });
  }
};