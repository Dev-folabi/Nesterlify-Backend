const express = require("express");

const auth = require("./routes/auth.route");
const user = require("./routes/user.route");
const cars = require("./routes/cars.route");
const hotels = require("./routes/hotels.route");
const flights = require("./routes/flights.route");
const binance = require("./routes/binance.route");



const router = express.Router();

router.use("/api/v1/auth", auth);
router.use("/api/v1/users", user);
router.use("/api/v1/cars", cars);
router.use("/api/v1/hotels", hotels);
router.use("/api/v1/flights", flights);
router.use("/api/v1/binance", binance);

module.exports = router; 