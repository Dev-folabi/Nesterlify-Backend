const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {

    username: {
      type: String,
      unique: true,
    },


    fullName: {
      type: String,
      required: true,
      trim: true,
    },


    email: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },

    password: {
      type: String,
      required: true,
    },


    role: {
      type: String,
      default: "user",
    },


    // Personal details

    profilePicture: {
      type: String,
      default:
        "https://media.istockphoto.com/id/1081381240/photo/young-smiling-african-american-man-over-white-background.jpg?s=612x612&w=0&k=20&c=T2Mq5yJ93H5jvbI87tC5RjXuGcmDdTH4GzcyOL_WRl4=",
    },

    title: {
      type: String,
      default: "",
    },

    gender: {
      type: String,
      default: "",
    },

    firstName: {
      type: String,
      default: "",
    },

    lastName: {
      type: String,
      default: "",
    },


    middleName: {
      type: String,
      default: "",
    },



    phoneNumber: {
      type: Number,
    },


    nationality: {
      type: String,
      default: "",
    },

    state: {
      type: String,
      default: "",
    },

    city: {
      type: String,
      default: "",
    },

    zipcode: {
      type: String,
      default: "",
    },


    houseNo: {
      type: String,
      default: "",
    },

    houseAddress: {
      type: String,
      default: "",
    },


    documenttype: {
      type: String,
      default: "",
    },

    issuedby: {
      type: String,
      default: "",
    },

    passportNo: {
      type: String,
      default: "",
    },

    passportExpiryDate: {
      type: String,
      default: "",
    },

    dirthOfBirth: {
      type: String,
      default: "",
    },

    isBlocked: {
      type: Boolean,
      default: false,
    },

    //settings

    notificationSettings: {
      website: {
        bookings: {
          type: Boolean,
          default: false,
        },

        cheapflight: {
          type: Boolean,
          default: false,
        },

        transaction: {
          type: Boolean,
          default: false,
        },

      },

      email: {
        bookings: {
          type: Boolean,
          default: false,
        },

        cheapflight: {
          type: Boolean,
          default: false,
        },

        transaction: {
          type: Boolean,
          default: false,
        },

      }
    },

    emailNotification: {
      type: Boolean,
      default: true,
    },

    twoFa: {
      type: Boolean,
      default: false,
    },


  },
  { timestamps: true }
);

module.exports = mongoose.model("User", userSchema); 