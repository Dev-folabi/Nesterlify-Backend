const jwt = require("jsonwebtoken");
const { errorHandler } = require("../middleware/errorHandler");
const User = require("../models/user.model");

exports.verifyToken = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return next(errorHandler(401, "You are not authenticated!"));
    }
    const token = authHeader.split(" ")[1];
    if (!token) {
      return next(errorHandler(401, "Token not provided"));
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id);

    if (!user) {
      return next(errorHandler(404, "User not found"));
    }
    req.user = user;
    next();
  } catch (err) {
    return next(errorHandler(403, "Token is not valid!"));
  }
};



exports.isAdmin = (...roles) => {
  return (req, res, next) => {
    console.log("User Data:", req.user);
    if (!req.user || !roles.includes(req.user.role)) {
      return next(
        errorHandler(
          403,
          `${req.user ? req.user.role : "user"} cannot access this resource`
        )
      );
    }
    next();
  };
};