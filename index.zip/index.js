const express = require("express");
const dotenv = require("dotenv");
const connectDB = require("./database/db");
const endpoints = require("./endpoints.js");
const cookieParser = require("cookie-parser"); 
const bodyParser = require("body-parser");
const User = require("./models/user.model.js");
const cors = require("cors")

//INVOKE  
const app = express(); 
dotenv.config();
app.use(express.json());
app.use(endpoints); 
app.use(cookieParser());
app.use(bodyParser.json());  
app.use(express.json()); ;

const allowedOrigins = [
  'http://localhost:5173'
];

app.use(cors({
  origin: function (origin, callback) {
    if (allowedOrigins.indexOf(origin) !== -1 || !origin) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
}));



app.use((err, req, res, next) => {
    const statusCode = err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    return res.status(statusCode).json({
        success: false,
        message,
        statusCode,
    });
});



const port = process.env.PORT || 8081;
const start = async () => {
    try {
        await connectDB(process.env.MONGO_URI);
        console.log("Connected to the database successfully!");
        app.listen(port, function () {
            console.log(`listening on port ${port}...`);
        });
    } catch (error) {
        console.error(`Failed to listen on port ${port}...`);
        console.error(error);
    }
};

start();